% Fourier analysis of 500 samples of a signal

% 2a)
s = @(t) sin(80*pi*t) + 0.5*sin(180*pi*t);
t = linspace(0, 0.5, 500);
y = arrayfun(s, t)
figure(1)
plot(t, y)
xlabel('Time (seconds)')
ylabel('Amplitude')
%-------------------------------------------------
%2b)
n=500
modes=(1/sqrt(n))*fmat(n)*y'
figure(2)
x = abs(modes)
plot([0:2:1000-2],x)
xlabel('Frequencies (Hz)')
ylabel('Amplitude')

%-------------------------------------------------
%2c)
firstTen = modes(1:10)
lastTen = modes(491:500)




