/*
========================================
 Przyk�ad do kursu WinAPI
 (c) 2004 by Z�o�liwiec
========================================
 Ten plik pochodzi ze strony
  www.darkcult.republika.pl
========================================
 Pytania, uwagi, sugestie:
  zlosliwiec1@op.pl
========================================
*/

#include <windows.h>

//Globalna zmienna, w kt�rej przechowamy uchwyt okna
HWND thwnd;

//To, co zawsze :-)
LRESULT CALLBACK WindowProcedure(HWND, UINT, WPARAM, LPARAM);
LPSTR szClassName = "KulkaClass";

//Kilka globalnych zmiennych
const WORD ID_TIMER = 1;
RECT rcKulka, rcOkno;
SHORT SpeedX=2, SpeedY=2;
HDC hdcMem, hdcBuf;
HBITMAP hbmKulka, hbmMaska, hbmOld, hbmBuf, hbmOldBuf;
BITMAP bmKulka;

//Najwa�niejsza funkcja programu :-)
void RysujKulke()
{
 //pobierz HDC okna
 HDC hdc = GetDC(thwnd);
 //zama� "star�" kulk� 
 FillRect(hdcBuf, &rcKulka, (HBRUSH)GetStockObject(LTGRAY_BRUSH));
 //wylicz nowe parametry kulki 
 if(rcKulka.left<=0 || rcKulka.right>=rcOkno.right) SpeedX = -SpeedX;
 if(rcKulka.top<=0 || rcKulka.bottom>=rcOkno.bottom) SpeedY = -SpeedY;
 OffsetRect(&rcKulka, SpeedX, SpeedY);
 //narysuj kul� na nowej pozycji
 //najpierw maska
 SelectObject(hdcMem, hbmMaska);
 BitBlt(hdcBuf, rcKulka.left, rcKulka.top, rcKulka.right-rcKulka.left, rcKulka.bottom-rcKulka.top, hdcMem, 0, 0, SRCAND);
 //potem sama kulka
 SelectObject(hdcMem, hbmKulka);
 BitBlt(hdcBuf, rcKulka.left, rcKulka.top, rcKulka.right-rcKulka.left, rcKulka.bottom-rcKulka.top, hdcMem, 0, 0, SRCINVERT); 
 //a na koniec wszystko l�duje na ekranie
 BitBlt(hdc, 0, 0, rcOkno.right, rcOkno.bottom, hdcBuf, 0, 0, SRCCOPY);
 //i wtedy znienacka zwalniamy kontekst ;-)
 ReleaseDC(thwnd, hdc);
}

//Oto nasza czarodziejska funkcja...
HBITMAP CreateBitmapMask(HBITMAP hbmColour, COLORREF crTransparent)
{
 HDC hdcMem, hdcMem2;
 HBITMAP hbmMask, hbmOld, hbmOld2;
 BITMAP bm;

 GetObject(hbmColour, sizeof(BITMAP), &bm);
 hbmMask = CreateBitmap(bm.bmWidth, bm.bmHeight, 1, 1, NULL);

 hdcMem = CreateCompatibleDC(NULL);
 hdcMem2 = CreateCompatibleDC(NULL);

 hbmOld = (HBITMAP)SelectObject(hdcMem, hbmColour);
 hbmOld2 = (HBITMAP)SelectObject(hdcMem2, hbmMask);

 SetBkColor(hdcMem, crTransparent);

 BitBlt(hdcMem2, 0, 0, bm.bmWidth, bm.bmHeight, hdcMem, 0, 0, SRCCOPY);
 BitBlt(hdcMem, 0, 0, bm.bmWidth, bm.bmHeight, hdcMem2, 0, 0, SRCINVERT);

 SelectObject(hdcMem, hbmOld);
 SelectObject(hdcMem2, hbmOld2);
 DeleteDC(hdcMem);
 DeleteDC(hdcMem2);

 return hbmMask;
}

int WINAPI WinMain(HINSTANCE hThisInstance, HINSTANCE hPrevInstance, LPSTR lpszArgument, int nFunsterStil)

{
    HWND hwnd;
    MSG messages;
    WNDCLASSEX wincl;
    
    wincl.hInstance = hThisInstance;
    wincl.lpszClassName = szClassName;
    wincl.lpfnWndProc = WindowProcedure;
    wincl.style = CS_DBLCLKS;       
    wincl.cbSize = sizeof(WNDCLASSEX);
    wincl.hIcon = LoadIcon(NULL, IDI_APPLICATION);
    wincl.hIconSm = LoadIcon(NULL, IDI_APPLICATION);
    wincl.hCursor = LoadCursor(NULL, IDC_ARROW);
    wincl.lpszMenuName = NULL;
    wincl.cbClsExtra = 0;
    wincl.cbWndExtra = 0;
    wincl.hbrBackground = (HBRUSH) GetStockObject(LTGRAY_BRUSH);

    if(!RegisterClassEx(&wincl)) return 0;

    hwnd = CreateWindowEx(
           0,                  
           szClassName,        
           "Kulka Rulez ;-)",      
           WS_OVERLAPPEDWINDOW,
           CW_USEDEFAULT,
           CW_USEDEFAULT,
           400,          
           250,          
           HWND_DESKTOP, 
           NULL,         
           hThisInstance,
           NULL
           );

    //tutaj mo�emy sobie zapami�ta� uchwyt okna
    thwnd = hwnd;
    ShowWindow(hwnd, nFunsterStil);
    
    //Pobieramy wymiary okna
    GetClientRect(hwnd, &rcOkno);    
    //wczytujemy kulk� z dysku
    hbmKulka = (HBITMAP)LoadImage(NULL, "kulka.bmp", IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);    
    //tworzymy do niej mask�
    hbmMaska = CreateBitmapMask(hbmKulka, RGB(255,0,255));
    //pobieramy jej wymiary i zapami�tujemy je
    GetObject(hbmKulka, sizeof(bmKulka), &bmKulka);
    SetRect(&rcKulka, 5, 5, 5+bmKulka.bmWidth, 5+bmKulka.bmHeight);
    //tworzymy rozmaite pomocnicze bufory :-)
    HDC hdc = GetDC(hwnd);
    hdcMem = CreateCompatibleDC(hdc);    
    hbmOld = (HBITMAP)SelectObject(hdcMem, hbmKulka);
    hdcBuf = CreateCompatibleDC(hdc);
    hbmBuf = CreateCompatibleBitmap(hdc, rcOkno.right, rcOkno.bottom);
    hbmOldBuf = (HBITMAP)SelectObject(hdcBuf, hbmBuf);
    //zamalowujemy najwa�niejszy bufor na szaro
    FillRect(hdcBuf, &rcOkno, (HBRUSH)GetStockObject(LTGRAY_BRUSH));
    ReleaseDC(hwnd, hdc);    
    //czas na czasomierz ;-)
    if(SetTimer(hwnd, ID_TIMER, 50, NULL) == 0)
     MessageBox(hwnd, "Nie mo�na utworzy� timera!", "Kurde", MB_ICONSTOP);    
        
    while(GetMessage(&messages, NULL, 0, 0))
    {
     TranslateMessage(&messages);
     DispatchMessage(&messages);
    }
         
    return messages.wParam;
}


LRESULT CALLBACK WindowProcedure(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    switch(message)
    {
           case WM_DESTROY:
           {
            //wielkie porz�dki...
            KillTimer(hwnd, ID_TIMER);
            SelectObject(hdcMem, hbmOld);            
            DeleteDC(hdcMem);
            SelectObject(hdcBuf, hbmOldBuf);
            DeleteDC(hdcBuf);
            DeleteObject(hbmBuf);
            DeleteObject(hbmKulka);
            DeleteObject(hbmMaska);
            PostQuitMessage(0);
           }
           break;
           case WM_TIMER:
            RysujKulke(); //wygl�da to skromnie, ale to do�� wa�na linijka ;-)
           break;
           default:
           return DefWindowProc(hwnd, message, wParam, lParam);
    }
    return 0;
}
