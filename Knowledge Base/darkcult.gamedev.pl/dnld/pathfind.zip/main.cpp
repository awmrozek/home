/*
========================================
 PathFinder, wersja 1.00
 (c) 2004 by Z�o�liwiec
========================================
 Ten plik pochodzi ze strony
  www.darkcult.republika.pl
========================================
 Pytania, uwagi, sugestie:
  zlosliwiec1@op.pl
========================================
*/

#include <windows.h>
#include <stdlib.h>
#include "klasy.h"
#include "pathfind.h"

WORD Mapa[MAX_Y][MAX_X]; // To nasza g��wna mapka - zera i jedynki
cPOS PunktA(0,0), PunktB(MAX_X-1,MAX_Y-1);
HWND hPrzycisk, hKoniec, hOpcja1, hOpcja2, hOpcja3;
cSTOS Droga, Droga2;
WORD Styl = STYL_PROSTAK;
WORD lx, ly;

/* Declare Windows procedure */
LRESULT CALLBACK WindowProcedure(HWND, UINT, WPARAM, LPARAM);
/* Make the class name into a global variable */
char szClassName[ ] = "WindowsApp";
int WINAPI WinMain(HINSTANCE hThisInstance, HINSTANCE hPrevInstance, LPSTR lpszArgument, int nFunsterStil)

{
    HWND hwnd;               /* This is the handle for our window */
    MSG messages;            /* Here messages to the application are saved */
    WNDCLASSEX wincl;        /* Data structure for the windowclass */

    /* The Window structure */
    wincl.hInstance = hThisInstance;
    wincl.lpszClassName = szClassName;
    wincl.lpfnWndProc = WindowProcedure;      /* This function is called by windows */
    wincl.style = CS_DBLCLKS;                 /* Catch double-clicks */
    wincl.cbSize = sizeof(WNDCLASSEX);

    /* Use default icon and mouse-pointer */
    wincl.hIcon = LoadIcon(NULL, IDI_APPLICATION);
    wincl.hIconSm = LoadIcon(NULL, IDI_APPLICATION);
    wincl.hCursor = LoadCursor(NULL, IDC_ARROW);
    wincl.lpszMenuName = NULL; /* No menu */
    wincl.cbClsExtra = 0;                      /* No extra bytes after the window class */
    wincl.cbWndExtra = 0;                      /* structure or the window instance */
    /* Use light-gray as the background of the window */
    wincl.hbrBackground = GetSysColorBrush(COLOR_3DFACE); //(HBRUSH) GetStockObject(LTGRAY_BRUSH);

    /* Register the window class, if fail quit the program */
    if(!RegisterClassEx(&wincl)) return 0;

    /* The class is registered, let's create the program*/
    hwnd = CreateWindowEx(
           0,                   /* Extended possibilites for variation */
           szClassName,         /* Classname */
           "PathFinder",        /* Title Text */
           WS_OVERLAPPED | WS_MINIMIZEBOX | WS_SYSMENU,
           CW_USEDEFAULT,       /* Windows decides the position */
           CW_USEDEFAULT,       /* where the window ends up on the screen */
           MAX_X*BMPS+100,      /* The programs width */
           MAX_Y*BMPS+28,       /* and height in pixels */
           HWND_DESKTOP,        /* The window is a child-window to desktop */
           NULL,                /* No menu */
           hThisInstance,       /* Program Instance handler */
           NULL                 /* No Window Creation data */
           );

     hPrzycisk = CreateWindowEx(WS_EX_DLGMODALFRAME, "BUTTON", "Droga", WS_CHILD | WS_VISIBLE | WS_BORDER, MAX_X*BMPS + 15, 200, 68, 28, hwnd, (HMENU)ID_PRZYC1, hThisInstance, NULL);
     hKoniec   = CreateWindowEx(WS_EX_DLGMODALFRAME, "BUTTON", "Exit",  WS_CHILD | WS_VISIBLE | WS_BORDER, MAX_X*BMPS + 15, 235, 68, 28, hwnd, (HMENU)ID_PRZYC2, hThisInstance, NULL);
     hOpcja1   = CreateWindowEx(0, "BUTTON", "Prostak", WS_CHILD | WS_VISIBLE | BS_RADIOBUTTON, MAX_X*BMPS + 15, 5,  68, 28, hwnd, (HMENU)ID_OPCJA1, hThisInstance, NULL);
     hOpcja2   = CreateWindowEx(0, "BUTTON", "Lewus",   WS_CHILD | WS_VISIBLE | BS_RADIOBUTTON, MAX_X*BMPS + 15, 38, 68, 28, hwnd, (HMENU)ID_OPCJA2, hThisInstance, NULL);
     hOpcja3   = CreateWindowEx(0, "BUTTON", "Pijak",   WS_CHILD | WS_VISIBLE | BS_RADIOBUTTON, MAX_X*BMPS + 15, 71, 68, 28, hwnd, (HMENU)ID_OPCJA3, hThisInstance, NULL);

     SendMessage(hOpcja1, BM_SETCHECK, BST_CHECKED, 0);

    /* Make the window visible on the screen */
    ShowWindow(hwnd, nFunsterStil);

    //Inicjalizacja mapy:
    //1.Spr�buj wczyta� map� z pliku
    HANDLE hFile = CreateFile("labirynt.bin", GENERIC_READ, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
    if(hFile != INVALID_HANDLE_VALUE)
    {
     if(GetFileSize(hFile, NULL)<MAX_X*MAX_Y*2)
     {
      MessageBox(hwnd, "Plik z danymi labiryntu jest uszkodzony." , "B��d", MB_ICONINFORMATION);
      DestroyWindow(hwnd);
     }
     DWORD dwRead;
     for(WORD i=0; i<MAX_Y; i++)
      ReadFile(hFile, Mapa[i], MAX_X*2, &dwRead, NULL);
     CloseHandle(hFile);
    }
    else
    //2....a je�li pliku nie ma, to zr�b byle co
    {
     for(WORD y=0; y<MAX_Y; y++)
      for(WORD x=0; x<MAX_X; x++)
       Mapa[y][x] = 1;
     for(WORD i=0; i<MAX_X/2; i++) Mapa[0][i]=0;
     for(WORD i=0; i<MAX_Y; i++) Mapa[i][MAX_X/2-1]=0;
     for(WORD i=MAX_X/2-1; i<MAX_X; i++) Mapa[MAX_Y-1][i]=0;
    }

    //Rysuj labirynt
    HDC hdc = GetDC(hwnd);
    Repaint(hdc);
    ReleaseDC(hwnd, hdc);

    /* Run the message loop. It will run until GetMessage( ) returns 0 */
    while(GetMessage(&messages, NULL, 0, 0))
    {
           /* Translate virtual-key messages into character messages */
           TranslateMessage(&messages);
           /* Send message to WindowProcedure */
           DispatchMessage(&messages);
    }

    /* The program return-value is 0 - The value that PostQuitMessage( ) gave */
    return messages.wParam;
}

/* This function is called by the Windows function DispatchMessage( ) */
LRESULT CALLBACK WindowProcedure(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
 WORD x,y;
 HDC hdc;
    switch (message)                  /* handle the messages */
    {
           /*case WM_KILLFOCUS:
            if(GetFocus()!=hwnd) SetFocus(hwnd);
           break;*/
           case WM_COMMAND:
           {
            switch(LOWORD(wParam)) //Selekcja identyfikator�w
            {
             case ID_PRZYC1:
             {
              cPOS P;
              bool d;
              if(Droga2.LiczbaEl() || PunktA.Dist(PunktB)<=1) break;
              SetCursor(LoadCursor(NULL, IDC_WAIT));
              d = SzukajDrogi(PunktA, PunktB, Droga, Styl, false);
              for(WORD y=0; y<MAX_Y; y++)
               for(WORD x=0; x<MAX_X; x++)
                if(Mapa[y][x]!=1) Mapa[y][x] = 0;
              if(!d)
              {
               SetCursor(LoadCursor(NULL, IDC_ARROW));
               MessageBox(hwnd, "Nie istnieje droga z punktu A do B.", "A to szkoda...", MB_ICONINFORMATION);
               break;
              }
              SetCursor(LoadCursor(NULL, IDC_ARROW));
              hdc = GetDC(hwnd);
              while(Droga.LiczbaEl())
              {
               Droga.Usun(&P);
               Koleczko(hdc, P.X*BMPS+1, P.Y*BMPS+1, COL_RED);
               Droga2.Dodaj(P); //Zapami�taj kolejne punkty, aby mo�na je by�o wyczy�ci�
              }
              ReleaseDC(hwnd, hdc);
             }
             break;
             case ID_PRZYC2:
              DestroyWindow(hwnd);
             break;
             case ID_OPCJA1: case ID_OPCJA2: case ID_OPCJA3:
             {
              Styl = LOWORD(wParam) - ID_OPCJA1;
              for(WORD i=ID_OPCJA1; i<=ID_OPCJA3; i++)
               SendMessage(GetDlgItem(hwnd, i), BM_SETCHECK, BST_UNCHECKED, 0);
              SendMessage((HWND)lParam, BM_SETCHECK, BST_CHECKED, 0);
              hdc = GetDC(hwnd);
              UsunDroge(hdc);
              ReleaseDC(hwnd, hdc);
             }
             break;
            }
           }
           break;
           case WM_PAINT:
           {
            PAINTSTRUCT ps;
            hdc = BeginPaint(hwnd, &ps);
            Repaint(hdc);
            EndPaint(hwnd, &ps);
           }
           break;
           case WM_LBUTTONDOWN:
           {
            if(wParam & MK_CONTROL)
             SendMessage(hwnd, WM_MOUSEMOVE, wParam, lParam);
            else
            {
             x = (LOWORD(lParam)-1)/BMPS;
             y = (HIWORD(lParam)-1)/BMPS;
             if(x>=MAX_X || y>=MAX_Y || Mapa[y][x]==1 || (x==PunktB.X&&y==PunktB.Y)) break;
             lx = ly = 0;
             hdc = GetDC(hwnd);
             UsunDroge(hdc);
             Prostokat(hdc, PunktA.X*BMPS+1, PunktA.Y*BMPS+1, COL_WHITE);
             Punkcik(hdc, x*BMPS+1, y*BMPS+1, COL_GREEN, 'A');
             PunktA = cPOS(x,y);
             ReleaseDC(hwnd, hdc);
            }
           }
           break;
           case WM_LBUTTONUP:
           {
            SendMessage(hwnd, WM_MOUSEMOVE, wParam, lParam);
           }
           break;
           case WM_RBUTTONDOWN:
           {
            if(wParam & MK_CONTROL)
             SendMessage(hwnd, WM_MOUSEMOVE, wParam, lParam);
            else
            {
             x = (LOWORD(lParam)-1)/BMPS;
             y = (HIWORD(lParam)-1)/BMPS;
             if(x>=MAX_X || y>=MAX_Y || Mapa[y][x]==1 || (x==PunktA.X&&y==PunktA.Y)) break;
             lx = ly = 0;
             hdc = GetDC(hwnd);
             UsunDroge(hdc);
             Prostokat(hdc, PunktB.X*BMPS+1, PunktB.Y*BMPS+1, COL_WHITE);
             Punkcik(hdc, x*BMPS+1, y*BMPS+1, COL_BLUE, 'B');
             PunktB = cPOS(x,y);
             ReleaseDC(hwnd, hdc);
            }
           }
           break;
           case WM_RBUTTONUP:
           {
            SendMessage(hwnd, WM_MOUSEMOVE, wParam, lParam);
           }
           break;
           case WM_MOUSEMOVE:
           {
            if(wParam & MK_CONTROL)
            {
             x = (LOWORD(lParam)-1)/BMPS;
             y = (HIWORD(lParam)-1)/BMPS;
             if(x>=MAX_X || y>=MAX_Y || (x==lx && y==ly) || (x==PunktA.X&&y==PunktA.Y) || (x==PunktB.X&&y==PunktB.Y) ) break;
             hdc = GetDC(hwnd);
             UsunDroge(hdc);
             if(wParam & MK_LBUTTON)
             {
              Mapa[y][x] = 1;
              Prostokat(hdc, x*BMPS+1, y*BMPS+1, COL_GRAY);
              lx = x; ly = y;
             }
             if(wParam & MK_RBUTTON)
             {
              Mapa[y][x] = 0;
              Prostokat(hdc, x*BMPS+1, y*BMPS+1, COL_WHITE);
              lx = x; ly = y;
             }
             ReleaseDC(hwnd, hdc);
            }
           }
           break;
           case WM_KEYDOWN:
           {
            if((int)wParam == VK_ESCAPE) DestroyWindow(hwnd);
            if((int)wParam == VK_F2)
            {
             hdc = GetDC(hwnd);
             UsunDroge(hdc);
             for(WORD iy=0; iy<MAX_Y; iy++)
              for(WORD ix=0; ix<MAX_X; ix++)
               if((ix!=PunktA.X || iy!=PunktA.Y) && (ix!=PunktB.X || iy!=PunktB.Y))
                Mapa[iy][ix] = 1;
             Repaint(hdc);
             ReleaseDC(hwnd, hdc);
            }
           }
           break;
           case WM_DESTROY:
            PostQuitMessage(0);        /* send a WM_QUIT to the message queue */
           break;

           default:                   /* for messages that we don't deal with */
           return DefWindowProc(hwnd, message, wParam, lParam);
    }
    return 0;
}

//Funkcja rysuje prostok�t o wybranym kolorze na danych wsp�rz�dnych okna
void Prostokat(HDC hdc, WORD x, WORD y, COLORREF c)
{
 HBRUSH hbrOld, hbrNew = CreateSolidBrush(c);
 HPEN hpnOld, hpnNew = CreatePen(PS_SOLID, 1, c);
 hbrOld = (HBRUSH)SelectObject(hdc, hbrNew);
 hpnOld = (HPEN)SelectObject(hdc, hpnNew);
 Rectangle(hdc, x, y, x+BMPS, y+BMPS);
 SelectObject(hdc, hbrOld);
 SelectObject(hdc, hpnOld);
 DeleteObject(hbrNew);
 DeleteObject(hpnNew);
}

//Rysuje k�eczko o wybranym kolorze (i czarnej ramce) na danych wsp�rz�dnych
void Koleczko(HDC hdc, WORD x, WORD y, COLORREF c)
{
 HBRUSH hbrOld, hbrNew = CreateSolidBrush(c);
 hbrOld = (HBRUSH)SelectObject(hdc, hbrNew);
 Ellipse(hdc, x, y, x+BMPS, y+BMPS);
 SelectObject(hdc, hbrOld);
 DeleteObject(hbrNew);
}

//Rysuje k�eczko z literk� w �rodku
void Punkcik(HDC hdc, WORD x, WORD y, COLORREF c, char l)
{
 SIZE ns;
 GetTextExtentPoint32(hdc, &l, 1, &ns);
 Koleczko(hdc, x, y, c);
 SetBkMode(hdc, TRANSPARENT);
 SetTextColor(hdc, COL_YELLOW);
 TextOut(hdc, x+(BMPS-ns.cx)/2, y+(BMPS-ns.cy)/2, &l, 1);
}

//Rysuje labirynt, zaznacza aktualne punkty i drog� mi�dzy nimi
void Repaint(HDC hdc)
{
 //Rysujemy labirynt - szare lub bia�e kwadraty
 for(WORD y=0; y<MAX_Y; y++)
  for(WORD x=0; x<MAX_X; x++)
   Prostokat(hdc, x*BMPS+1, y*BMPS+1, (Mapa[y][x]==0)?COL_WHITE:COL_GRAY);
 //Rysujemy ramk� wok� labiryntu
 HBRUSH hbrOld = (HBRUSH)SelectObject(hdc, (HBRUSH)GetStockObject(HOLLOW_BRUSH));
 Rectangle(hdc, 0, 0, MAX_X*BMPS+2, MAX_Y*BMPS+2);
 SelectObject(hdc, hbrOld);
 Punkcik(hdc, PunktA.X*BMPS+1, PunktA.Y*BMPS+1, COL_GREEN, 'A');
 Punkcik(hdc, PunktB.X*BMPS+1, PunktB.Y*BMPS+1, COL_BLUE,  'B');
}

//Funkcja zwracacj�ca losow� liczb� z przedzia�u <a;b>
inline int Losowa(int a, int b) { return (rand()%(b+1-a))+a; }

//SERCE PROGRAMU - POSZUKIWANIE NAJKR�TSZEJ DROGI
bool SzukajDrogi(cPOS A, cPOS B, cSTOS& csDroga, WORD wStyl, bool TylkoSprawdz)
{
 bool Gol = false;        //czy droga istnieje?
 cKOLEJKA Kolejka;        //nasza kolejka punkt�w
 cPOS CurP,               //aktualnie badany punkt
      tmpP,               //pomocnicza zmienna
      Warta(-1,-1);       // "wartownik"
 WORD NbrCount;           //liczba "prawid�owych" s�siad�w badanego punktu
 DWORD licznik = 3;       //licznik badanych punkt�w

 Kolejka.Dodaj(A);        //Pierwszy punkt poszukiwa� to A
 Kolejka.Dodaj(Warta);    //Pierwszy wartownik musi by� postawiony na zewn�trz p�tli
 Mapa[A.Y][A.X] = 2;      //Punkt A jest jedynym na mapie oznaczonym liczb� 2
 do
 {
  Kolejka.Usun(&CurP);    //We� kolejny punkt i zarazem usu� go z kolejki
  if(CurP == Warta)       //Je�li bie��cy punkt to "wartownik", to zwi�ksz licznik i bierz nast�pny punkt
  {
   if(Kolejka.LiczbaEl()==0) break; //...chyba �e wartownik jest ostatnim punktem w kolejce (tzn. nie ma drogi)
   ++licznik;
   Kolejka.Dodaj(Warta);  //Postaw "wartownika"
   continue;
  }
  NbrCount = 0;
  for(int i=1; i<=8; i++) //zbadaj otoczenie bie��cego punktu
  {
   tmpP = CurP + CurP.GetNeighbor(i);
   if(tmpP.X>=0 && tmpP.Y>=0 && tmpP.X < MAX_X && tmpP.Y < MAX_Y)
    if(tmpP == B) //Osi�gn�li�my nasz cel...
    {
     Gol = true;
     break;
    }
    else if(Mapa[tmpP.Y][tmpP.X] == 0) //zakolejkuj punkt do przysz�ego zbadania
    {
     Kolejka.Dodaj(tmpP);
     Mapa[tmpP.Y][tmpP.X] = licznik;
     ++NbrCount;
    }
  }
 }
 while(!Gol);

 if(TylkoSprawdz) return Gol;
 if(!Gol) return false;

 //Analiza oznaczonych punkt�w w poszukiwaniu najkr�tszej �cie�ki
 WORD Mniejszy[8], Wyb;
 CurP = B;
 do
 {
  ZeroMemory(Mniejszy, 8*2);
  for(int i=1; i<=8; i++)
  {
   tmpP = CurP + CurP.GetNeighbor(i);
   if(tmpP.X>=0 && tmpP.Y>=0 && tmpP.X < MAX_X && tmpP.Y < MAX_Y)
    if(Mapa[tmpP.Y][tmpP.X] == licznik-1) //zaznacz, �e ten punkt bierzemy pod uwag�
     Mniejszy[i-1] = 1;
  }
  //wybierz losowy punkt spo�r�d zaznaczonych
  switch(wStyl)
  {
   case STYL_PIJAK:
    while(Mniejszy[Wyb=Losowa(0,7)]!=1);
   break;
   case STYL_LEWUS:
   {
    Wyb=0;
    while(Mniejszy[++Wyb-1]!=1);
    Wyb--;
   }
   break;
   case STYL_PROSTAK:
   {
    Wyb=8;
    while(Mniejszy[--Wyb]!=1);
   }
  }
  //dodaj go do drogi
  CurP = CurP + CurP.GetNeighbor(Wyb+1);
  csDroga.Dodaj(CurP);
 }
 while(--licznik>3);

 return true;
}

//Je�li aktualnie narysowana jest jaka� droga, to ta funkcja j� zama�e ;-)
void UsunDroge(HDC hdc)
{
 cPOS P;
 while(Droga2.LiczbaEl()/*>1*/)
 {
  Droga2.Usun(&P);
  Prostokat(hdc, P.X*BMPS+1, P.Y*BMPS+1, COL_WHITE);
 }
 //Droga2.Usun(NULL);
}
