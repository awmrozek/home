/*
========================================
 Klasa punktu, prostok�ta oraz kolejki
 (c) 2004 by Z�o�liwiec
========================================
 Ten plik pochodzi ze strony
  www.darkcult.republika.pl
========================================
 Pytania, uwagi, sugestie:
  zlosliwiec1@op.pl
========================================
*/

#ifndef KLASY_H
#define KLASY_H

class cRECT;
class cDROGA;

class cPOS
{
 public:
  short int X, Y;
  cPOS(short int a=0, short int b=0);
  cPOS GetNeighbor(BYTE);
  cPOS  operator+ (cPOS p)  const;
  cPOS  operator- (cPOS p)  const;
  cPOS& operator= (const cPOS& p);
  cPOS& operator+=(cPOS& p);
  cPOS& operator-=(cPOS& p);
  bool  operator==(cPOS& p) const;
  bool  operator!=(cPOS& p) const;
  friend bool operator<(cPOS p, cRECT r);
  friend bool operator>(cPOS p, cRECT r);
  friend bool operator<=(cPOS p, cRECT r);
  friend bool operator>=(cPOS p, cRECT r);
  WORD Dist(cPOS& p) const;
};

class cKOLEJKA
{
 private:
  struct tELEM
  {
   cPOS Dane;
   tELEM* Next;
  } *Pierwszy, *Ostatni;
  DWORD elcount;
 public:
  cKOLEJKA();
  ~cKOLEJKA();
  void Dodaj(cPOS elem);
  void Usun(cPOS* databuf);
  DWORD LiczbaEl();
  cPOS Status(DWORD index);
};

class cSTOS
{
 private:
  struct tELEM
  {
   cPOS Dane;
   tELEM* Prev;
  } *Ostatni;
  DWORD elcount;
 public:
  cSTOS();
  ~cSTOS();
  void Dodaj(cPOS elem);
  void Usun(cPOS* databuf);
  DWORD LiczbaEl();
  cPOS Status(DWORD index);
};

class cRECT
{
public: 
 WORD X, Y, W, H;
 cRECT(WORD=0, WORD=0, WORD=0, WORD=0);
 cRECT(cRECT&);
 cRECT(RECT);
 bool operator==(cRECT) const;
 bool operator!=(cRECT) const;
 bool operator<(cRECT) const;
 bool operator>(cRECT) const;
 bool operator<=(cRECT) const;
 bool operator>=(cRECT) const;
 cRECT operator=(cRECT);
 operator RECT() const;
 friend bool operator<(cPOS p, cRECT r);
 friend bool operator>(cPOS p, cRECT r);
 friend bool operator<=(cPOS p, cRECT r);
 friend bool operator>=(cPOS p, cRECT r);
 cPOS GetXY() const;
 WORD Dist(cRECT& r) const;
};

#endif