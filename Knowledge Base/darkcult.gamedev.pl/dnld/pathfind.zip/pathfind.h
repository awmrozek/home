/*
========================================
 PathFinder, wersja 1.00
 (c) 2004 by Z�o�liwiec
========================================
 Ten plik pochodzi ze strony
  www.darkcult.republika.pl
========================================
 Pytania, uwagi, sugestie:
  zlosliwiec1@op.pl
========================================
*/

#ifndef PATHFIND_H
#define PATHFIND_H

#define   BMPS   16
#define   MAX_X  30
#define   MAX_Y  20
#define   STYL_PIJAK   2
#define   STYL_LEWUS   1 
#define   STYL_PROSTAK 0
#define   COL_GRAY   0x808080
#define   COL_WHITE  0xFFFFFF
#define   COL_GREEN  0x008000
#define   COL_BLUE   0xFF0000
#define   COL_YELLOW 0x00FFFF
#define   COL_RED    0x0000FF
#define   ID_PRZYC1  0x500
#define   ID_PRZYC2  0x501
#define   ID_OPCJA1  0x502
#define   ID_OPCJA2  0x503
#define   ID_OPCJA3  0x504
#define   ID_OPCJA4  0x505

void Repaint(HDC hdc);
void Koleczko(HDC hdc, WORD x, WORD y, COLORREF c);
void Prostokat(HDC hdc, WORD x, WORD y, COLORREF c);
void Punkcik(HDC hdc, WORD x, WORD y, COLORREF c, char l);
inline int Losowa(int a, int b);
bool SzukajDrogi(cPOS A, cPOS B, cSTOS& ckDroga, WORD wStyl, bool TylkoSprawdz);
void UsunDroge(HDC hdc);

#endif
