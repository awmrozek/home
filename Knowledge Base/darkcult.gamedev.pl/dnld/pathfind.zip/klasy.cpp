/*
========================================
 Klasa punktu, prostok�ta oraz kolejki
 (c) 2004 by Z�o�liwiec
========================================
 Ten plik pochodzi ze strony
  www.darkcult.republika.pl
========================================
 Pytania, uwagi, sugestie:
  zlosliwiec1@op.pl
========================================
*/

#include <windows.h>
#include <stdlib.h>
#include "klasy.h"

// =====================
//  KLASA PUNKTU (cPOS)
// =====================

cPOS::cPOS(short int a, short int b) {X=a; Y=b;}
cPOS  cPOS::operator+ (cPOS p)  const { return cPOS(X+p.X, Y+p.Y);                }
cPOS  cPOS::operator- (cPOS p)  const { return cPOS(X-p.X, Y-p.Y);                }
cPOS& cPOS::operator= (const cPOS& p) { this->X=p.X;  this->Y=p.Y;  return *this; }
cPOS& cPOS::operator+=(cPOS& p)       { X+=p.X; Y+=p.Y; return *this;             }
cPOS& cPOS::operator-=(cPOS& p)       { X-=p.X; Y-=p.Y; return *this;             }
bool  cPOS::operator==(cPOS& p) const { return (p.X==X && p.Y==Y);                }
bool  cPOS::operator!=(cPOS& p) const { return (p.X!=X || p.Y!=Y);                }

cPOS cPOS::GetNeighbor(BYTE PosIndex)
{
 switch(PosIndex)
 {
  case 1: return cPOS(-1,-1); break;
  case 2: return cPOS( 0,-1); break;
  case 3: return cPOS( 1,-1); break;
  case 4: return cPOS( 1, 0); break;
  case 5: return cPOS( 1, 1); break;
  case 6: return cPOS( 0, 1); break;
  case 7: return cPOS(-1, 1); break;
  case 8: return cPOS(-1, 0); break;
  default: return cPOS(0, 0);
 }
}

WORD cPOS::Dist(cPOS& p) const { return (WORD)sqrt((X-p.X)*(X-p.X)+(Y-p.Y)*(Y-p.Y)); }

// ==========================
//  KLASA PROSTOK�TA (cRECT)
// ==========================

cRECT::cRECT(WORD nx, WORD ny, WORD nw, WORD nh)
{ X = nx; Y = ny; W = nw; H = nh; }

cRECT::cRECT(cRECT& NRect)
{
 X = NRect.X; Y = NRect.Y;
 W = NRect.W; H = NRect.H;
}

cRECT::cRECT(RECT NRect)
{
 X = NRect.left; Y = NRect.top;
 W = NRect.right - NRect.left;
 H = NRect.bottom - NRect.top;
}

bool cRECT::operator==(cRECT R) const
{ return (X==R.X && Y==R.Y && W==R.W && H==R.H); }

bool cRECT::operator!=(cRECT R) const
{ return (X!=R.X || Y!=R.Y || W!=R.W || H!=R.H); }

bool cRECT::operator<(cRECT R) const
{ return (X>R.X && Y>R.X && X<R.X+R.W && H<R.Y+R.H); }

bool cRECT::operator>(cRECT R) const
{ return !(X>R.X && Y>R.X && X<R.X+R.W && H<R.Y+R.H); }

bool cRECT::operator<=(cRECT R) const
{ return (X>=R.X && Y>=R.X && X<=R.X+R.W && H<=R.Y+R.H); }

bool cRECT::operator>=(cRECT R) const
{ return !(X>=R.X && Y>=R.X && X<=R.X+R.W && H<=R.Y+R.H); }

cRECT cRECT::operator=(cRECT R)
{ X=R.X; Y=R.Y; W=R.W; H=R.H; return *this;}
               /*
cRECT::operator RECT() const
{
 RECT tmp;
 tmp.left = X;
 tmp.top  = Y
 tmp.right = X + W;
 tmp.bottom = Y + H;
 return LONG t=tmp;
}             */

cPOS cRECT::GetXY() const { return cPOS(X, Y); }

WORD cRECT::Dist(cRECT& r) const
{
 
}

// ==============================================================
//  OPERATORY DO SPRAWDZANIA ZAWIERANIA SI� PUNKTU W PROSTOK�CIE
// ==============================================================

bool operator<(cPOS p, cRECT r)
{ return (p.X>r.X && p.Y>r.Y && p.X < r.X+r.W && p.Y < r.Y+r.H); }

bool operator>(cPOS p, cRECT r)
{ return !(p.X>r.X && p.Y>r.Y && p.X < r.X+r.W && p.Y < r.Y+r.H); }

bool operator<=(cPOS p, cRECT r)
{ return (p.X>=r.X && p.Y>=r.Y && p.X <= r.X+r.W && p.Y <= r.Y+r.H); }

bool operator>=(cPOS p, cRECT r)
{ return !(p.X>=r.X && p.Y>=r.Y && p.X <= r.X+r.W && p.Y <= r.Y+r.H); }

// ======================================
//  IMPLEMENTACJA KOLEJKI DLA KLASY cPOS
// ======================================

cKOLEJKA::cKOLEJKA()
{
 elcount=0;
 Pierwszy = Ostatni = NULL;
}

cKOLEJKA::~cKOLEJKA()
{
 for(DWORD i=0; i<elcount; i++)
 Usun(NULL);
}

void cKOLEJKA::Dodaj(cPOS elem)
{
 tELEM* Cur = new tELEM;
 if(++elcount==1)
  Pierwszy = Cur;
 else
  Ostatni->Next = Cur;
 Cur->Dane = elem;
 Cur->Next = NULL;
 Ostatni = Cur;
}

void cKOLEJKA::Usun(cPOS* databuf)
{
 if(elcount<1) return;
 if(databuf!=NULL) *databuf=Pierwszy->Dane; //zwr�� usuwany element
 tELEM *tmp = Pierwszy->Next;               //zapami�taj drugi element
 delete Pierwszy;                           //skasuj pierwszy element
 Pierwszy = tmp;                            //drugi element staje si� pierwszym
 if(--elcount==0) Pierwszy = NULL;
}

DWORD cKOLEJKA::LiczbaEl() { return elcount; }

cPOS cKOLEJKA::Status(DWORD index)
{
 tELEM* Cur = Pierwszy;
 DWORD licznik=0;
 while(Cur!=NULL)
 {
  if(licznik++==index) return Cur->Dane;
  Cur = Cur->Next;
 }
 return cPOS(0,0);
}

// ====================================
//  IMPLEMENTACJA STOSU DLA KLASY cPOS
// ====================================

cSTOS::cSTOS() { elcount=0; Ostatni = NULL; }

cSTOS::~cSTOS()
{
 for(int i=0; i<elcount; i++)
  Usun(NULL);
}

void cSTOS::Dodaj(cPOS elem)
{
 tELEM* Cur = new tELEM;
 Cur->Prev = (++elcount==1) ? NULL : Ostatni;
 Cur->Dane = elem;
 Ostatni = Cur;
}

void cSTOS::Usun(cPOS* databuf)
{
 if(elcount<1) return;
 if(databuf!=NULL) *databuf=Ostatni->Dane; //zwr�� usuwany element
 tELEM *tmp = Ostatni->Prev;               //zapami�taj przedostatni element
 delete Ostatni;                           //skasuj go
 Ostatni = tmp;                            //przedostatni element staje si� ostatnim
 if(--elcount==0) Ostatni = NULL; 
}

DWORD cSTOS::LiczbaEl() { return elcount; }

cPOS cSTOS::Status(DWORD index)
{
 tELEM* Cur = Ostatni;
 DWORD licznik=elcount;
 while(Cur!=NULL)
 {
  if(--licznik==index) return Cur->Dane;
  Cur = Cur->Prev;
 }
 return 0;
}
