#ifndef PBSTRING_H
#define PBSTRING_H

#include <windows.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <iostream.h>

enum SearchTypeConsts
{
 pbsBINARY_SEARCH,
 pbsTEXT_SEARCH
};

class PBString
{
 private:
  char* dane;
  int dlugosc;
  char* tokstr;
  int firsttok;
  static int liczba_obszarow;
  static int liczba_obiektow;
  static char** tab_wsk;
  static void dodaj_obszar(char*);
 public:
  PBString();
  PBString(char);
  PBString(const char*);
  PBString(const PBString&);
  ~PBString(); 
  operator const char*() const;  //konwersja PBString na char*
  operator char() const;         //konwersja PBString na char
  PBString operator+(const PBString&) const;

  friend PBString operator+(const char*, const PBString&);
  friend PBString operator+(const PBString&, const char*);
  friend PBString operator+(char, const PBString&);
  friend PBString operator+(const PBString&, char);
  friend PBString operator+(long, const PBString&); //bazowy - long
  friend PBString operator+(const PBString&, long);
  friend PBString operator+(int, const PBString&);  //int
  friend PBString operator+(const PBString&, int);
  friend PBString operator+(short, const PBString&); //short
  friend PBString operator+(const PBString&, short);
  friend PBString operator+(unsigned char, const PBString&); //BYTE
  friend PBString operator+(const PBString&, unsigned char);

  PBString& operator+=(const PBString&);
  PBString& operator+=(const char*);
  PBString& operator+=(char);
  PBString& operator+=(long);
  PBString& operator+=(int);
  PBString& operator+=(short);
  PBString& operator+=(unsigned char);

  PBString& operator=(const PBString&);
  PBString& operator=(const char*);
  PBString& operator=(char);
  PBString& operator=(long);
  PBString& operator=(int);
  PBString& operator=(short);
  PBString& operator=(unsigned char);

  int operator==(const PBString&) const;
  int operator==(const char*) const;
  int operator==(char) const;
  int operator!=(const PBString&) const;
  int operator!=(const char*) const;
  int operator!=(char) const;
  char& operator [] (unsigned int) const;
  friend ostream& operator<<(ostream&, const PBString&);
  int Len() const;
  int Search(unsigned int, const PBString&, int=pbsBINARY_SEARCH) const;
  PBString GetMirror() const;
  PBString Mirror();
  PBString UCase() const;
  PBString MakeUCase();
  PBString LCase() const;
  PBString MakeLCase();
  PBString Mid(unsigned int, unsigned int) const;
  PBString Left(unsigned int) const;
  PBString Right(unsigned int) const;
  long int Integer() const;
  double Double() const;
  void ResetTok();
  void EndTok();
  PBString Tok(const PBString);
  int Span(const PBString) const;
  int Complement(const PBString) const;
  PBString PointerBreak(const PBString) const;
  PBString GetFileExt() const;
  PBString GetFileExtDot() const;
  PBString GetFileTitle() const;
  PBString GetFileTitleExt() const;
  PBString GetPrevDir(unsigned int=2) const;
  PBString GetFilePath() const;
  PBString& Fill(BYTE, unsigned int);
  PBString Dec(long);
  PBString Hex(long);
  PBString Bin(long);
  long int WriteToFile(HANDLE, unsigned long int=0) const;
  long int ReadFromFile(HANDLE, unsigned long int=0);
  long int ReadLine(HANDLE);
  PBString& Format(const char*, long int, unsigned int);
  void DeleteBuffer(char* buf=NULL); //const
};

typedef PBString String;

#endif
