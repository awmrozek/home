/*
========================================
 WinRobak, wersja 1.00
 (c) 2004 by Z�o�liwiec
========================================
 Ten plik pochodzi ze strony
  www.darkcult.republika.pl
========================================
 Pytania, uwagi, sugestie:
  zlosliwiec1@op.pl
========================================
*/

#include "robak.h"

LRESULT CALLBACK WindowProcedure(HWND, UINT, WPARAM, LPARAM);
char szClassName[] = "WindowsApp";
HCURSOR hcuStrzalka; //uchwyt odmy�lnego kursora (strza�ki)
cPOLE Pole; //ta zmienna to esencja gry ;-)

int WINAPI WinMain(HINSTANCE hThisInstance, HINSTANCE hPrevInstance, LPSTR lpszArgument, int nFunsterStil)
{
 //ca�kowicie standardowa procedura okienkowa...
    HWND hwnd;
    MSG messages;
    WNDCLASSEX wincl;

    wincl.hInstance = hThisInstance;
    wincl.lpszClassName = szClassName;
    wincl.lpfnWndProc = WindowProcedure;
    wincl.style = CS_DBLCLKS;
    wincl.cbSize = sizeof(WNDCLASSEX);

    wincl.hIcon = LoadIcon(NULL, IDI_APPLICATION);
    wincl.hIconSm = LoadIcon(NULL, IDI_APPLICATION);
    wincl.hCursor = LoadCursor(NULL, IDC_ARROW); hcuStrzalka = wincl.hCursor; //zapami�taj ten kursor
    wincl.lpszMenuName = NULL;
    wincl.cbClsExtra = 0;
    wincl.cbWndExtra = 0;
    wincl.hbrBackground = (HBRUSH)GetStockObject(LTGRAY_BRUSH);

    if(!RegisterClassEx(&wincl)) return 0;

    hwnd = CreateWindowEx(
           0,
           szClassName,
           "WinRobak",
           WS_OVERLAPPED|WS_SYSMENU|WS_THICKFRAME|WS_MINIMIZEBOX,
           20,
           0,
           POLE_WIDTH*BMP_W+8,
           POLE_HEIGHT*BMP_H+PANEL_HEIGHT+20,
           HWND_DESKTOP,
           NULL,
           hThisInstance,
           NULL
           );

    ShowWindow(hwnd, nFunsterStil);

    Pole.Init(hwnd);

    while(GetMessage(&messages, NULL, 0, 0))
    {
           TranslateMessage(&messages);
           DispatchMessage(&messages);
    }
    return messages.wParam;
}

LRESULT CALLBACK WindowProcedure(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    switch (message)
    {
           case WM_TIMER:
           {
            Pole.Move(); //Rusz robaka o 1 pole do przodu
           }
           break;
           case WM_CLOSE:
           {
            //Je�li robak si� porusza, to zatrzymaj go
            if(Pole.Akcja()==0) Pole.StopAction(1);
            DestroyWindow(hwnd);
           }
           break;
           case WM_DESTROY:
           {
            PostQuitMessage(0);
           }
           break;
           case WM_MOUSEMOVE: //User ruszy� mysz�
           {
            if(GetCursor()==NULL) SetCursor(hcuStrzalka); //Poka� kursor (je�li by� schowany)
           }
           break;
           case WM_SYSCOMMAND: //Co� si� dzieje z okienkiem...
           {
            switch(wParam & 0xFFF0) //...sprawd�, co
            {
             case SC_MINIMIZE: //User zrzuci� okno do paska!
             {
              if(Pole.Akcja()==0)
               Pole.StopAction(2); //Trza zrobi� pauz� w takim przypadku
              return DefWindowProc(hwnd, message, wParam, lParam); //To trzeba dorzuci�, �eby dzia�a�o...
             }
             break;
             default:
              return DefWindowProc(hwnd, message, wParam, lParam);
            }
           }
           break;
           case WM_KEYDOWN:  //Obs�uga klawiatury
           {
            BYTE akcja = Pole.Akcja(); //Sprawd�, czy robak si� porusza czy nie
            if(akcja==1) //Akcja == 1, czyli robak chwilowo nie �yje ;-)
            {
             Pole.Reset(); //Za�aduj aktualny poziom od nowa
             Pole.ResumeAction(); //Wzn�w akcj�
             break;
            }
            else if(akcja==2) //Akcja == 2, czyli user zrobi� pauz�
            {
             Pole.ResumeAction(); //Wy��cz pauz� i kontynuuj gr�
             break;
            }
            SetCursor(NULL); //Schowaj kursor - po co ma przeszkadza�
            switch(wParam)
            {
             case VK_UP: //Gracz wcisn�� kt�r�� ze strza�ek
              Pole.ZmienKier(1);
             break;
             case VK_RIGHT:
              Pole.ZmienKier(2);
             break;
             case VK_DOWN:
              Pole.ZmienKier(3);
             break;
             case VK_LEFT:
              Pole.ZmienKier(4);
             break;
             case VK_PAUSE: case 0x50: //Gracz zrobi� pauz� (przycisk Pause lub P)
              if(Pole.Akcja()==0) Pole.StopAction(2);
             break;
             case VK_ESCAPE:      //Gracz wcisn�� Esc (wyj�cie z programu)
              PostMessage(hwnd, WM_SYSCOMMAND, SC_CLOSE, 0);
             break;
            }
           }
           break;
           default:
           return DefWindowProc(hwnd, message, wParam, lParam);
    }
    return 0;
}

int Losowa(int a, int b)
{
 //Generuje losow� liczb� z przedzia�u <a; b>
 return (rand()%(b+1-a))+a;
}

HFONT ZrobFonta(LPCSTR FontName, WORD FontSize, BYTE FontStyle)
{
 //Tworzy fonta o nazwie FontName i rozmiarze FontSize
 //Mo�na ustawia� dodatkowe style przy pomocy sta�ych zadeklarowanych
 //w pliku robak.h (zaczynaj� si� od "FONT_")
 bool bItalic, bUnder, bStrike;
 int fWeight = FW_NORMAL;
 HDC hDC = GetDC(NULL);
 LONG lfHeight = -MulDiv(FontSize, GetDeviceCaps(hDC, LOGPIXELSY), 72);
 ReleaseDC(NULL, hDC);
 if(FontStyle & FONT_LIGHT) fWeight = FW_THIN;
 if(FontStyle & FONT_BOLD) fWeight = FW_BOLD;
 if(FontStyle & FONT_ULTRABOLD) fWeight = FW_EXTRABOLD;
 bItalic = (FontStyle & FONT_ITALIC);
 bUnder  = (FontStyle & FONT_UNDERLINE);
 bStrike = (FontStyle & FONT_STRIKEOUT);
 return CreateFont(lfHeight, 0, 0, 0, fWeight, bItalic, bUnder, bStrike, EASTEUROPE_CHARSET, 0, 0, 0, 0, FontName);
}
