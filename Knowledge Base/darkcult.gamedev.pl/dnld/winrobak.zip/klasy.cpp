/*
========================================
 WinRobak, wersja 1.00
 (c) 2004 by Z�o�liwiec
========================================
 Ten plik pochodzi ze strony
  www.darkcult.republika.pl
========================================
 Pytania, uwagi, sugestie:
  zlosliwiec1@op.pl
========================================
*/

#include "robak.h"

void cPOLE::cROBAK::Init(cPOLE* wsk)
{
 //Funkcja s�u�y do przekazania klasie cROBAK wska�nika do oiektu cPOLE
 //A poza tym r�wnie� ustawia poczatkow� liczb� �y� robaka
 wskpole = wsk;
 zycia = 3;
}

void cPOLE::cROBAK::Reset()
{
 //Ta funkcja wywo�ywana jest za ka�dym razem, kiedy robak zmartwychwstaje
 //albo zaczyna nowy poziom
 dl = START_LEN;         //pocz�tkowa d�ugo��
 kier = 1;               //w g�r�
 dod = 0;                //na razie robak nie ro�nie
 for(int i=0; i<dl; i++) //ustaw pocz�tkowe wsp�rz�dne
 {
  posx[i] = wskpole->startpx[wskpole->poziom-1];
  posy[i] = wskpole->startpy[wskpole->poziom-1] - dl + i;
  wskpole->dane[posy[i]][posx[i]] = ID_ROBAK;
 }
}

void cPOLE::cROBAK::Move()
{
 //Robak robi krok naprz�d
 bool rpanel = false; //czy trzeba od�wie�y� liczby na panelu
 WORD ostx, osty;     //wsp�rz�dne ostatniego kaw��ka robaka
 int nextx, nexty;    //wsp�rz�dne kwadratu, w kt�ry robimy ten krok
 //Wylicz nast�pne wsp�rz�dne g�owy robaka
 switch(kier)
 {
  case 1: {nextx=posx[0]; nexty=(posy[0]>0)?posy[0]-1:POLE_HEIGHT-1;} break;
  case 2: {nextx=(posx[0]<POLE_WIDTH-1)?posx[0]+1:0; nexty=posy[0];} break;
  case 3: {nextx=posx[0]; nexty=(posy[0]<POLE_HEIGHT-1)?posy[0]+1:0;} break;
  case 4: {nextx=(posx[0]>0)?posx[0]-1:POLE_WIDTH-1; nexty=posy[0];} break;
 }
 BYTE cd = wskpole->dane[nexty][nextx];

 //Sprawd�, w co wdepn�li�my
 switch(cd)
 {
  case ID_ROBAK: case ID_WALL: //W siebie albo w mur - na jedno wychodzi (death)
  {
   wskpole->RobakIsDead();
   return;
  }
  break;
  case ID_NUM: //W numerek - oby tak dalej!
  {
   dod += wskpole->num; //Robak ro�nie o warto�� numerka
   wskpole->Num();      //Ustaw nast�pny numerek
  }
 }
 //Zapami�taj wsp�rz�dne ostatniego fragmentu odw�oka
 ostx = posx[dl-1];
 osty = posy[dl-1];
 //Przemie�� wszystkie fragmenty do przodu (ucinaj�c ostatni)
 for(int i=dl-1; i>0; i--)
 {
  posx[i] = posx[i-1];
  posy[i] = posy[i-1];
 }
 //Ustaw wsp�rz�dne g�owy na nast�pn� pozycj�
 posx[0] = nextx;
 posy[0] = nexty;
 //Stablicuj nowe wsp�rz�dne g�owy i narysuj j�
 HDC hdc = GetDC(wskpole->thwnd);
 wskpole->dane[posy[0]][posx[0]] = ID_ROBAK;
 wskpole->Prostokat(hdc, posx[0]*BMP_W,posy[0]*BMP_H, ID_ROBAK);
 if(dod) //Je�li robak ro�nie...
 {
  dl++;              //Zwi�ksz d�ugo��
  dod--;
  posx[dl-1] = ostx; //Przywr�� ostatni fragment (uci�li�my go w p�tli for)
  posy[dl-1] = osty;
  rpanel = true;     //Trzeba b�dzie od�wie�y� panel (wzros�a d�ugo�� robaka)
 }
 else    //Je�li nie ro�nie... Zama� ostatni fragemnt - na ekranie i w tablicy
 {
  wskpole->dane[osty][ostx] = ID_POLE;
  wskpole->Prostokat(hdc, ostx*BMP_W, osty*BMP_H, ID_POLE);
 }
 ReleaseDC(wskpole->thwnd, hdc);
 if(rpanel) wskpole->Panel.Refresh(); //Od�wie� panel, je�li trzeba
}

cPOLE::cPOLE()
{
 //Konstruktor. Tworzy te� obiekty Robak i Panel, inicjalizuje je,
 //tworzy wszelkie p�dzle, czcionki i pi�ra, u�ywane do rysowania pola gry,
 //wreszcie wczytuje dane poziom�w z pliku.
 Robak.Init(this);      //Inicjalizacja obiekt�w Robak i Panel
 Panel.Init(this);
 srand(GetTickCount()); //Inicjalizacja generatora losowych liczb
 poziom = 1;

 //Tworzenie font�w, p�dzli i pi�r
 NowyFont = ZrobFonta("Tahoma", 9, 0);
 hbrPole  = CreateSolidBrush(CLR_POLE);
 hbrRobak = CreateSolidBrush(CLR_ROBAK);
 hbrWall  = CreateSolidBrush(CLR_WALL);
 hpnPole  = CreatePen(PS_SOLID, 1, CLR_POLE);
 hpnRobak = CreatePen(PS_SOLID, 1, CLR_POLE);
 hpnWall  = CreatePen(PS_SOLID, 1, CLR_WALL);

 //Zapami�tywanie domy�lnego pi�ra i p�dzla
 HDC tmp   = GetDC(thwnd);
 Pudelko   = (HBRUSH)SelectObject(tmp, hbrPole);
 Piornik   = (HPEN)SelectObject(tmp, hpnPole);
 StaryFont = (HFONT)SelectObject(tmp, NowyFont);
 ReleaseDC(thwnd, tmp);

 //Wczytywanie danych poziom�w
 HANDLE hFile = CreateFile("robak.rlv", GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, 0, NULL);
 if(hFile!=INVALID_HANDLE_VALUE)
 {
  DWORD dwFileSize = GetFileSize(hFile, NULL);
  if(dwFileSize != 0xFFFFFFFF)
  {
   DWORD dwRead;
   ReadFile(hFile, &maxlvl, 1, &dwRead, NULL);
   if(maxlvl>0)
   {
    BYTE *tmp;
    startpx = (BYTE*)GlobalAlloc(GPTR, maxlvl);
    startpy = (BYTE*)GlobalAlloc(GPTR, maxlvl);
    tmp     = (BYTE*)GlobalAlloc(GPTR, maxlvl);
    lvldata = (BYTE*)GlobalAlloc(GPTR, maxlvl*POLE_WIDTH*POLE_HEIGHT);
    if(lvldata!=NULL)
    {
     ReadFile(hFile, startpx, maxlvl, &dwRead, NULL);
     ReadFile(hFile, startpy, maxlvl, &dwRead, NULL);
     ReadFile(hFile, tmp, maxlvl, &dwRead, NULL); //To s� startowe pozycje drugiego gracza
     ReadFile(hFile, tmp, maxlvl, &dwRead, NULL); //(nie s� wykorzystywane w tej wersji)
     ReadFile(hFile, lvldata, maxlvl*POLE_WIDTH*POLE_HEIGHT, &dwRead, NULL);
    }
    GlobalFree(tmp);
   }
   CloseHandle(hFile);
  }
 }
}

cPOLE::~cPOLE()
{
 //Destruktor.
 //Zwalnia wszystkie zasoby.
 GlobalFree(startpx);
 GlobalFree(startpy);
 GlobalFree(lvldata);
 HDC tmp = GetDC(thwnd);
 SelectObject(tmp, Pudelko);
 SelectObject(tmp, Piornik);
 SelectObject(tmp, StaryFont);
 ReleaseDC(thwnd, tmp);
 DeleteObject(hbrPole);
 DeleteObject(hpnPole);
 DeleteObject(hbrRobak);
 DeleteObject(hpnRobak);
 DeleteObject(hbrWall);
 DeleteObject(hpnWall);
 DeleteObject(NowyFont);
}

void cPOLE::Init(HWND hwnd)
{
 //Inicjalizacja gry. Ta funkcja powinna by� wywo�ana w WinMain.
 thwnd = hwnd;
 Reset();
}

void cPOLE::Reset()
{
 //Rozpocz�cie gry na aktualnym poziomie od nowa.

 //Ustaw tablic� danych poziomu
 for(int y=0; y<POLE_HEIGHT; y++)
 for(int x=0; x<POLE_WIDTH; x++)
  dane[y][x] = 2-lvldata[POLE_WIDTH*POLE_HEIGHT*(poziom-1)+y*POLE_WIDTH+x];

 Robak.Reset(); //Robak na pozycj� startow�!
 num = 1;       //Pocz�tkowy numerek
 WORD nx,ny;    //Losowanie pozycji numerka
 do { nx = Losowa(0, POLE_WIDTH-1); ny = Losowa(0, POLE_HEIGHT-1); } while (dane[ny][nx]);
 dane[ny][nx] = ID_NUM; //Ustawienie numerka
 atype = 1;             //Na pocz�tku akcja zatrzymana

 Panel.Rysuj();         //Narysuj panel...
 HDC hdc = GetDC(thwnd);//Kr�tka instrukcja dla niekumatych
 Napis(hdc, "Gotowy? Wci�nij co�!");
 ReleaseDC(thwnd, hdc);
}

void cPOLE::Move()
{
 Robak.Move(); //Rusz ty�ek, robalu!

 //Sprawd�, czy d�ugo�� robala nie jest ju� przypadkiem wystarczaj�ca
 if(Robak.dl>=MAX_DL) //Nast�pny poziom!
 {
  if(++poziom>maxlvl) //Cel gry osi�gni�ty!
  {
   StopAction(4);          //Koniec wysi�k�w...
   HDC hdc = GetDC(thwnd); //Narysujmy sobie co� fajnego...
   LPSTR napis = "Gratulacje! Gra uko�czona!";
   SIZE ssize;
   SelectObject(hdc, CreateSolidBrush(0));       //Czarne t�o
   SelectObject(hdc, CreatePen(PS_SOLID, 1, 0)); //j.w.
   SelectObject(hdc, ZrobFonta("Tahoma", 14, FONT_BOLD));
   GetTextExtentPoint32(hdc, napis, lstrlen(napis), &ssize);            //Wylicz wymiary napisu
   WORD tx = (POLE_WIDTH*BMP_W-ssize.cx)/2, ty = (POLE_HEIGHT*BMP_H)/2; //Wsp�rz�dne napisu
   Rectangle(hdc, 0, 0, POLE_WIDTH*BMP_W, POLE_HEIGHT*BMP_H);
   SetTextColor(hdc, 0x00FFFFFF);   //Na razie rysuj na bia�o
   SetBkColor(hdc, 0);              //i na czarnym tle
   TextOut(hdc, tx, ty, napis, lstrlen(napis));
   //Pokoloruj �adnie napis
   for(WORD ky=ty; ky<ty+ssize.cy; ky++)
   for(WORD kx=tx; kx<tx+ssize.cx; kx++)
    if(GetPixel(hdc, kx, ky)!=0) SetPixelV(hdc, kx, ky, RGB(255, 255-(kx-tx), 0));
   ReleaseDC(thwnd, hdc);
  }
  else                //Zaczynamy nowy poziom
  {
   StopAction(1);  //Ale nie zaczynamy od razu
   Reset();        //Ustaw nowy poziom
  }
 }
}

void cPOLE::Refresh()
{
 //Od�wie�a ca�y obszar pola gry
 WORD id;
 HDC hdc = GetDC(thwnd);
 char nn[2]; //bufor na cyferk� :-)

 for(int y=0; y<POLE_HEIGHT; y++)
 for(int x=0; x<POLE_WIDTH; x++)
 {
  Prostokat(hdc, x*BMP_W, y*BMP_H, dane[y][x]);
  if(dane[y][x] == ID_NUM)
  {
   ::ltoa(num, nn, 10);          //konwertuj cyferk� na stringa
   SetTextColor(hdc, CLR_FONT1); //ustaw kolor tekstu
   SetBkMode(hdc, TRANSPARENT);  //przezroczyste t�o tekstu
   TextOut(hdc, x*BMP_W, y*BMP_H, nn, 1); //narysuj cyferk�
  }
 } 
 ReleaseDC(thwnd, hdc);
 Panel.Rysuj(); //od�wie� panel
}

void cPOLE::ZmienKier(BYTE NKier)
{
 //Zmiana kierunku robaka
 //Pierwsza linijka to zabezpieczenie przed zbyt gwa�townymi zwrotami ;-)
 if(NKier*Robak.kier==3 || NKier*Robak.kier==8) return;
 Robak.kier = NKier;
}

void cPOLE::Num()
{
 //Ustawia nast�pny numerek. Je�li robak w�a�nie po�kn�� dziewi�tk�, to
 //funkcja nic nie robi
 if(++num<=9)
 {
  HDC hdc = GetDC(thwnd);
  char nn[2];
  ::ltoa(num, nn, 10);
  WORD x,y;
  do { x = Losowa(0, POLE_WIDTH-1); y = Losowa(0, POLE_HEIGHT-1); } while (dane[y][x]);
  dane[y][x] = ID_NUM;
  SetTextColor(hdc, CLR_FONT1);
  SetBkMode(hdc, TRANSPARENT);
  TextOut(hdc, x*BMP_W, y*BMP_H, nn, 1);
  ReleaseDC(thwnd, hdc);
 }
}

void cPOLE::RobakIsDead()
{
 //Ukatrupienie robaka
 SIZE StrSize;
 LPSTR RDead = "Robak zdech�", PressKey = "Wci�nij co�...";
 HDC hdc = GetDC(thwnd);
 if(Robak.zycia>0) //Je�li mamy jakie� �ycia w zapasie, to dobrze...
 {
  --Robak.zycia;
  //Zr�b stosowny napisik
  SetBkMode(hdc, TRANSPARENT);
  SetTextColor(hdc, CLR_ROBAK);
  GetTextExtentPoint32(hdc, RDead, lstrlen(RDead), &StrSize);
  TextOut(hdc, (POLE_WIDTH*BMP_W-StrSize.cx)/2, POLE_HEIGHT*BMP_H/2, RDead, lstrlen(RDead));
  SetTextColor(hdc, CLR_PANEL);
  GetTextExtentPoint32(hdc, PressKey, lstrlen(PressKey), &StrSize);
  TextOut(hdc, (POLE_WIDTH*BMP_W-StrSize.cx)/2, POLE_HEIGHT*BMP_H/2+20, PressKey, lstrlen(PressKey));
  //Zatrzymaj akcj�
  StopAction(1);
 }
 else //...a je�li nie mamy wi�cej �y�, to trudno si� m�wi ;-)
 {
  Napis(hdc, "Robak jest ju� definitywnie sztywny...");
  StopAction(3);
 }
 ReleaseDC(thwnd, hdc);
}

void cPOLE::StopAction(BYTE StopType)
//Zatrzymanie akcji.
//StopType = 1 - zatrzymanie akcji przed rozpocz�ciem ka�dego poziomu
//StopType = 2 - pauza
//StopType = 3 - robak nieboszczyk (na dobre)
//StopType = 4 - gra uko�czona
{
 atype = StopType;
 KillTimer(thwnd, 1); //zatrzymaj timera
 //Usu� wszystkie komunikaty z kolejki
 MSG tmpmsg;
 while(PeekMessage(&tmpmsg, thwnd, 0, 0, PM_REMOVE));
 //Pauza - zr�b odpowiedni napis
 if(StopType==2)
 {
  HDC hdc = GetDC(thwnd);
  Napis(hdc, "PAUZA");
  ReleaseDC(thwnd, hdc);
 }
}

void cPOLE::ResumeAction()
//Wznowienie akcji
{
 atype = 0;
 Refresh();
 SetTimer(thwnd, 1, TIMER_INTERVAL, NULL);
}

BYTE cPOLE::Akcja()
//Zwraca kod, z jakim zosta�� zatrzymana akcja (parametr StopType)
//lub 0 je�li robak aktualnie si� porusza
{
 return atype;
}

void cPOLE::Prostokat(HDC hdc, WORD x, WORD y, WORD id)
//Rysuje prostok�t o wymiarach BMP_W x BMP_H w podanym kwadracie pola gry
//Argument id okre�la, co si� znajduje w danym kwadracie
{
 HBRUSH hbrBrush;
 HPEN   hpnPen;
 switch(id) //Dobierz odpowiedni p�dzel i pi�ro
 {
  case ID_NUM:
  {
   hbrBrush = hbrPole;
   hpnPen   = hpnPole;
  }
  break;
  case ID_ROBAK:
  {
   hbrBrush = hbrRobak;
   hpnPen   = hpnRobak;
  }
  break;
  case ID_WALL:
  {
   hbrBrush = hbrWall;
   hpnPen   = hpnWall;
  }
  break;
  default:
  {
   hbrBrush = hbrPole;
   hpnPen   = hpnPole;
  }
 }
 SelectObject(hdc, hbrBrush);
 SelectObject(hdc, hpnPen);
 Rectangle(hdc, x, y, x+BMP_W, y+BMP_H);
}

void cPOLE::Napis(HDC hdc, LPCSTR txt)
//Robi napis na �rodku pola gry
{
 SelectObject(hdc, hbrPole);
 SelectObject(hdc, hpnPole);
 Rectangle(hdc, 0, 0, POLE_WIDTH*BMP_W, POLE_HEIGHT*BMP_H);
 SIZE StrSize;
 GetTextExtentPoint32(hdc, txt, lstrlen(txt), &StrSize);
 SetTextColor(hdc, CLR_PANEL);
 SetBkMode(hdc, TRANSPARENT);
 TextOut(hdc, (POLE_WIDTH*BMP_W-StrSize.cx)/2, (POLE_HEIGHT*BMP_H)/2, txt, lstrlen(txt));
}

cPOLE::cPANEL::cPANEL()
//Konstruktor - tworzy pi�ro, p�dzel i czcionk�, kt�rymi rysowany jest panel
{
 hbrPanel = CreateSolidBrush(CLR_PANEL);
 hpnPanel = CreatePen(PS_SOLID, 1, CLR_PANEL);
 fntPanel = ZrobFonta("Tahoma", 9, FONT_BOLD);
}

cPOLE::cPANEL::~cPANEL()
//Destruktor - zwalnia zasoby
{
 DeleteObject(hbrPanel);
 DeleteObject(hpnPanel);
 DeleteObject(fntPanel);
}

void cPOLE::cPANEL::Rysuj()
//Rysowanie ca�ego panelu
{
 HDC hdc = GetDC(wskpole->thwnd);
 SelectObject(hdc, hbrPanel);
 SelectObject(hdc, hpnPanel);
 Rectangle(hdc, 0, POLE_HEIGHT*BMP_H, POLE_WIDTH*BMP_W, POLE_HEIGHT*BMP_H+PANEL_HEIGHT);
 ReleaseDC(wskpole->thwnd, hdc);
 Refresh();
}

void cPOLE::cPANEL::Refresh()
//Od�wie�enie liczb na panelu
{
 char S[36], *poz="Poziom:   ", *zyc="   �ycia:   ", *dlu="   D�ugo��:   ";
 HDC hdc = GetDC(wskpole->thwnd);
 SelectObject(hdc, hbrPanel);
 SelectObject(hdc, hpnPanel);
 Rectangle(hdc, 5, POLE_HEIGHT*BMP_H+5, POLE_WIDTH*BMP_W, POLE_HEIGHT*BMP_H+20);
 SelectObject(hdc, fntPanel);
 SetBkMode(hdc, TRANSPARENT);
 SetTextColor(hdc, CLR_FONT2);
 //Troch� zabawy ze stringami :-/
 lstrcpy(S, poz);
 lstrcpy(S+10, zyc);
 lstrcpy(S+22, dlu);
 ltoa(wskpole->poziom, S+8, 10);
 ltoa(wskpole->Robak.zycia, S+20, 10);
 ltoa(wskpole->Robak.dl, S+34, 10);
 if(S[9]==0) S[9]=' '; S[10]=' ';
 if(S[21]==0) S[21]=' ';
 if(S[35]==0) S[35]=' ';
 //Wreszcie wypisywanie ca�ego statusu gry na panelu
 TextOut(hdc, 5, POLE_HEIGHT*BMP_H+5, S, 36);
 ReleaseDC(wskpole->thwnd, hdc);
}

void cPOLE::cPANEL::Init(cPOLE* wsk)
//Inicjalizacja klasy wska�nikiem do pola gry
{
 wskpole = wsk;
}
