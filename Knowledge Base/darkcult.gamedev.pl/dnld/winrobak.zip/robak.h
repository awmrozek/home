/*
========================================
 WinRobak, wersja 1.00
 (c) 2004 by Z�o�liwiec
========================================
 Ten plik pochodzi ze strony
  www.darkcult.republika.pl
========================================
 Pytania, uwagi, sugestie:
  zlosliwiec1@op.pl
========================================
*/

#ifndef ROBAK_H
#define ROBAK_H

#include <windows.h>
#include <stdlib.h>
#include <string.h>

//Wymiary prostok�t�w, kt�re sk�adaj� si� na grafik� gry ;-)
#define BMP_W 10
#define BMP_H 15

//R�ne sta�e
#define START_LEN        5 //Pocz�tkowa d�ugo�� robaka
#define POLE_WIDTH      60 //Wymiary pola gry (w prostok�tach)
#define POLE_HEIGHT     30
#define PANEL_HEIGHT    30 //Wysoko�� panelu (w pikselach)
#define MAX_DL          50 //Maksymalna d�ugo�� robaka
#define TIMER_INTERVAL 150 //Co ile milisekund timer wysy�a komunikat WM_TIMER

//Kolorki u�ywane w grze
#define CLR_POLE  0x00000000 
#define CLR_ROBAK 0x007777FF
#define CLR_WALL  0x00FFFFFF
#define CLR_PANEL 0x0000FFFF
#define CLR_FONT1 0x0000FF00
#define CLR_FONT2 0x00000000

//Takie warto�ci mog� by� wpisane w tablic� dane klasy cPOLE
#define ID_POLE  0 //pusta przestrze�
#define ID_WALL  1 //�ciana
#define ID_ROBAK 2 //kawa�ek robaka
#define ID_NUM   3 //aktualny numerek

//Style czcionek (do funkcji ZrobFonta)
#define FONT_BOLD       1
#define FONT_ITALIC     2
#define FONT_UNDERLINE  4
#define FONT_STRIKEOUT  8
#define FONT_ULTRABOLD  16
#define FONT_LIGHT      32

//Prototypy pomocniczych funkcji (definicje w pliku robmain.cpp)
int Losowa(int a, int b);
HFONT ZrobFonta(LPCSTR FontName, WORD FontSize, BYTE FontStyle);


//KLASY...

class cPOLE
//To g��wna klasa gry. Reprezentuje pole gry wraz z biegaj�cym po nim robakiem
// oraz panelem, gdzie wy�wietlane s� �ycia robaka, poziom i aktualna d�ugo��
{
 private:
  class cROBAK;           //Zapowied� klasy cROBAK (�eby da�o si� j� zaprzyja�ni� z cPANEL)
  class cPANEL            //Klasa zagnie�d�ona cPANEL (jest sk�adow� klasy cPOLE)
  {
   friend class cPOLE;    //Klasy cPOLE i cROBAK maj� dost�p do wszystkich sk�adowych
   friend class cROBAK;
   cPOLE* wskpole;        //Wska�nik do obiektu cPOLE (�eby z klasy cPANEL da�o si�
                          //uzyska� dost�p do zmiennych i funkcji klasy cPOLE)
   HBRUSH hbrPanel;       //P�dzel, pi�ro i czcionka, u�ywane do narysowania panelu
   HPEN hpnPanel;
   HFONT fntPanel;
   cPANEL();              //Konstruktor i destruktor
   ~cPANEL();
   void Init(cPOLE* wsk); //S�u�y do przekazania adresu obiektu cPOLE klasie cPANEL
   void Rysuj();          //Rysuje ca�y panel
   void Refresh();        //Od�wie�a t� cz�� panelu, gdzie s� napisy
  };
  class cROBAK            //Klasa zagnie�d�ona cROBAK (jest sk�adow� klasy cPOLE)
  {
   friend class cPOLE;    //Klasy cPOLE i cPANEL mog� grzeba� w tej klasie
   friend class cPANEL; 
   WORD dl,               //Aktualna d�ugo�� robaka
        dod,              //Ile musimy jeszcze doda� do d�ugo�ci (je�li rbak po�knie numerek)
        kier,             //Aktualny kierunek ruchu (1-4)
        zycia;            //Ile razy robak mo�e jeszcze zmartwychwsta� :-)
   WORD posx[MAX_DL],
        posy[MAX_DL];     //Wsp�rz�dne ka�dej cz�ci odw�oka
   cPOLE* wskpole;        //Wska�nik do obiektu cPOLE (�eby z klasy cRBAK da�o si�
                          //uzyska� dost�p do zmiennych i funkcji klasy cPOLE)
   void Init(cPOLE* wsk); //S�u�y do przekazania adresu obiektu cPOLE klasie cROBAK
   void Reset();          //Ustawia robaka na domy�lnych wsp�rz�dnych i nadaje mu domy�ln�                           //d�ugo��
   void Move();           //Przesuwa robaka o 1 kwadrat do przodu
  };
  BYTE dane[POLE_HEIGHT][POLE_WIDTH]; //Ta tablica okre�la, co jest w danym kwadracie pola
  cROBAK Robak; //Nasz g��wny bohater
  cPANEL Panel; //Panel...
  HWND thwnd;   //Uchwyt g��wnego okna (pobieramy go w funkcji Init)
  BYTE num,     //Aktualny numerek
       poziom,  //Aktualny numer poziomu
       atype,   //Okre�la, czy robak aktualnie si� porusza czy z jakich� powod�w stoi w miejscu
       maxlvl,  //Maksymalna liczba zdefiniowanych poziom�w w pliku robak.rlv
      *startpx, //Tablica startowych pozycji dla ka�dego poziomu.
      *startpy, //Uwaga! Zawiera dane dla DW�CH graczy! (tak na przysz�o��)
      *lvldata; //Dane poziom�w (wczytywane z pliku)
  //P�dzle, pi�ra i czcionki u�yte w grze
  HBRUSH hbrPole, hbrRobak, hbrWall, Pudelko;
  HPEN   hpnPole, hpnRobak, hpnWall, Piornik;
  HFONT StaryFont, NowyFont;

  void Prostokat(HDC hdc, WORD x, WORD y, WORD id); //Rysuje prostok�cik  
  void Num();                                       //Ustawia nast�pny numerek
  void RobakIsDead();                               //U�mierca robaka
 public:
  friend class cPANEL;                 //Ta klasa przed nikim nie ma sekret�w :-)             
  friend class cROBAK;          
  cPOLE();                             //Konstruktor i destruktor
  ~cPOLE();  
  void Init(HWND hwnd);                //Inicjalizacja klasy - s�u�y do przekazania uchwytu do                                          //okna
  void Refresh();                      //Od�wie�a ca�e pole gry
  void Move();                         //Rusz robakiem
  void Reset();                        //Rozpocznij poziom od nowa
  void ZmienKier(BYTE NKier);          //Zmie� kierunek na podany
  BYTE Akcja();                        //Sprawdza, czy na polu gry si� co� dzieje czy nie
  void StopAction(BYTE StopType);      //Zatrzymuje gr�
  void ResumeAction();                 //Wznawia gr�
  void Napis(HDC hdc, LPCSTR txt);     //Pisze napis :-). Na �rodeczku pola gry.
};

#endif
