/*
========================================
 Przyk�ad do kursu DirectDraw
 (c) 2004 by Z�o�liwiec
========================================
 Ten plik pochodzi ze strony
  www.darkcult.republika.pl
========================================
 Pytania, uwagi, sugestie:
  zlosliwiec1@op.pl
========================================
*/

#include <windows.h>
#include <ddraw.h>

//globalne zmienne
const WORD MaxKlatek = 9;
const WORD CEL_X = 75, CEL_Y = 10;
DWORD StaryCzas = 0, NowyCzas;
WORD Klatka = 0, Szer, Wys;
RECT Kadr, Cel, Tlo;

LPDIRECTDRAW lpDD = NULL;
LPDIRECTDRAWSURFACE lpEkran = NULL;
LPDIRECTDRAWSURFACE lpBufor = NULL;
LPDIRECTDRAWSURFACE lpObrazek = NULL;
LPDIRECTDRAWSURFACE lpTlo = NULL;

//Funkcja do konwersji kolor�w na format DX-a
DWORD Kolor32(BYTE r, BYTE g, BYTE b)
{
 return 0xFF000000 | (r << 16) | (g << 8) | b; 
}

//Wersja dla posiadaczy s�abszych kart (np. dla mnie ;-) )
/*
WORD Kolor16(BYTE r, BYTE g, BYTE b)
{
 WORD Czer5 = (r >> 3);
 WORD Ziel6 = (g >> 2);
 WORD Nieb5 = (b >> 3);
 return (Czer5 << 11) | (Ziel6 << 5) | Nieb5;
}
*/

LPDIRECTDRAWSURFACE WyczarujPowierzchnie(HWND hwnd, LPCSTR NazwaPliku)
{
 LPDIRECTDRAWSURFACE temp = NULL;
 HBITMAP hbmBitmapa, hbmOld;
 BITMAP bmp;
 HDC hdc, hdcTemp;

 //Wczytanie bitmay i pobranie jej wymiar�w
 hbmBitmapa = (HBITMAP)LoadImage(NULL, NazwaPliku, IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);
 GetObject(hbmBitmapa, sizeof(bmp), &bmp);

 //Utworzenie roboczego kontekstu
 hdc = GetDC(hwnd);
 hdcTemp = CreateCompatibleDC(hdc);
 ReleaseDC(hwnd, hdc);
 hbmOld = (HBITMAP)SelectObject(hdcTemp, hbmBitmapa);
 
 //Tworzenie powierzchni
 DDSURFACEDESC ddsd;
 ddsd.dwSize = sizeof(ddsd);
 ddsd.dwFlags = DDSD_CAPS | DDSD_WIDTH | DDSD_HEIGHT;
 ddsd.ddsCaps.dwCaps = DDSCAPS_OFFSCREENPLAIN | DDSCAPS_SYSTEMMEMORY;
 ddsd.dwWidth = bmp.bmWidth;
 ddsd.dwHeight = bmp.bmHeight;
 if(lpDD->CreateSurface(&ddsd, &temp, NULL) == DD_OK)
 {  
  //Kopiowanie z kontekstu na powierzchni�
  temp->GetDC(&hdc);
  BitBlt(hdc, 0, 0, bmp.bmWidth, bmp.bmHeight, hdcTemp, 0, 0, SRCCOPY);
  temp->ReleaseDC(hdc);
 }
 
 //Tego ju� nie potrzebujemy
 SelectObject(hdcTemp, hbmOld);
 DeleteDC(hdcTemp);
 DeleteObject(hbmBitmapa);

 //Wynik...
 return temp;
}

//Usuwa wszelkie obiekty DD
void Sprzatanie()
{
 if(lpEkran != NULL) { lpEkran->Release(); lpEkran = NULL; }
 if(lpObrazek != NULL) { lpObrazek->Release(); lpObrazek = NULL; }
 if(lpTlo != NULL) { lpTlo->Release(); lpTlo = NULL; }
 if(lpDD != NULL) { lpDD->Release(); lpDD = NULL; }
}

//Najwa�niejsza funkcja w programie...
void Renderuj()
{
 lpBufor->Blt(&Tlo,lpTlo,&Tlo,DDBLT_WAIT,NULL);
 lpBufor->Blt(&Cel,lpObrazek,&Kadr,DDBLT_KEYSRC | DDBLT_WAIT,NULL);
 lpEkran->Flip(NULL,DDFLIP_WAIT);
}

LRESULT CALLBACK WindowProcedure(HWND, UINT, WPARAM, LPARAM);
LPSTR szClassName = "WindowsApp";

int WINAPI WinMain(HINSTANCE hThisInstance, HINSTANCE hPrevInstance, LPSTR lpszArgument, int nFunsterStil)

{
    HWND hwnd;         
    MSG msg;           
    WNDCLASSEX wincl;  

    wincl.hInstance = hThisInstance;
    wincl.lpszClassName = szClassName;
    wincl.lpfnWndProc = WindowProcedure;
    wincl.style = CS_DBLCLKS;         
    wincl.cbSize = sizeof(WNDCLASSEX);
    wincl.hIcon = LoadIcon(NULL, IDI_APPLICATION);
    wincl.hIconSm = LoadIcon(NULL, IDI_APPLICATION);
    wincl.hCursor = LoadCursor(NULL, IDC_ARROW);
    wincl.lpszMenuName = NULL;
    wincl.cbClsExtra = 0; 
    wincl.cbWndExtra = 0; 
    wincl.hbrBackground = (HBRUSH) GetStockObject(LTGRAY_BRUSH);

    if(!RegisterClassEx(&wincl)) return 0;

    hwnd = CreateWindowEx(
           0,             
           szClassName,   
           "Windows App", 
           WS_POPUP,
           CW_USEDEFAULT, 
           CW_USEDEFAULT, 
           544,           
           375,           
           HWND_DESKTOP,  
           NULL,          
           hThisInstance, 
           NULL          
           );
  
    //Tworzymy obiekt g��wny DirectDraw
    if(DirectDrawCreate(NULL, &lpDD, NULL) != DD_OK)
    {
     MessageBox(hwnd,"B��d przy tworzeniu obiektu DD","Fatalnie!",MB_ICONSTOP);
     Sprzatanie();
     return FALSE;
    }
    //Ustawiamy tryb wsp�pracy
    lpDD->SetCooperativeLevel(hwnd, DDSCL_EXCLUSIVE | DDSCL_FULLSCREEN);
    lpDD->SetDisplayMode(800, 600, 16);

    //Utworzenie powierzchni
    lpTlo = WyczarujPowierzchnie(hwnd, "back.bmp");
    lpObrazek = WyczarujPowierzchnie(hwnd, "obrazek.bmp");
    if(lpTlo == NULL || lpObrazek == NULL)
    {
     MessageBox(hwnd,"Nici z utworzenia powierzchni","O �esz!",MB_ICONSTOP);
     Sprzatanie();
     return FALSE;
    }
    
    //Uzupe�niamy dane o prostok�tach
    SetRect(&Tlo, 0, 0, 300, 150);
    Szer = 150;
    Wys  = 135;
    SetRect(&Kadr, 0, 0, Szer, Wys);
    SetRect(&Cel, CEL_X, CEL_Y, CEL_X + Szer, CEL_Y + Wys);            
    
    //Tworzymy �a�cuch bufor�w
    DDSURFACEDESC ddsd;
    ddsd.dwSize = sizeof(ddsd);
    ddsd.dwFlags = DDSD_CAPS | DDSD_BACKBUFFERCOUNT;
    ddsd.ddsCaps.dwCaps = DDSCAPS_PRIMARYSURFACE | DDSCAPS_COMPLEX | DDSCAPS_FLIP;
    ddsd.dwBackBufferCount = 1;
    if(lpDD->CreateSurface(&ddsd,&lpEkran,NULL) != DD_OK)
    {
     MessageBox(hwnd,"Bufor�w niestety nie b�dzie...","Co za pech!",MB_ICONSTOP);
     Sprzatanie();
     return FALSE;
    }
    
    //Pobieramy wska�nik do tylnego bufora
    ddsd.ddsCaps.dwCaps = DDSCAPS_BACKBUFFER;
    lpEkran->GetAttachedSurface(&ddsd.ddsCaps, &lpBufor);
    
    //Ustawiamy kluczowanie koloru r�owego :-)
    DDCOLORKEY ddck;
    ddck.dwColorSpaceLowValue = ddck.dwColorSpaceHighValue = Kolor16(255,0,255);
    lpObrazek->SetColorKey(DDCKEY_SRCBLT,&ddck);

    ShowWindow(hwnd, nFunsterStil);
    
    //Nasza przerobiona p�tla komunikat�w
    while(msg.message != WM_QUIT)
    {
     if(PeekMessage(&msg,NULL,0,0,PM_REMOVE)) 
     {
      TranslateMessage(&msg);
      DispatchMessage(&msg);
     }
     else 
     {
      //Sprawd�, czy ju� trzeba rysowa� now� klatk�
      NowyCzas = GetTickCount();
      if(StaryCzas + 100 <= NowyCzas)
      {
       //Oj, trzeba trzeba ;-)
       Renderuj();       
       //Nowa klatko, pora na ciebie!
       ++Klatka;
       if(Klatka >= MaxKlatek) Klatka = 0;
       StaryCzas = NowyCzas;
       //Kadrujemy...
       Kadr.left = Klatka * Szer;
       Kadr.right = Kadr.left + Szer;       
      }
     }
    }    
    return msg.wParam;
}

LRESULT CALLBACK WindowProcedure(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    switch (message)
    {
           case WM_KEYDOWN:
           {
            //Szybkie wyj�cie z programu - ESC
            if(wParam==VK_ESCAPE) DestroyWindow(hwnd);
           }
           break;
           case WM_DESTROY:
           {
            Sprzatanie();
            PostQuitMessage(0);            
           } 
           break;
           default:
            return DefWindowProc(hwnd, message, wParam, lParam);
    }
    return 0;
}
