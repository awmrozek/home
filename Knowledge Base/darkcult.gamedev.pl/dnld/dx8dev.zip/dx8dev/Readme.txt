Using Directx8 in Dev-C++

Check my website for updates and tutorials..
(www.gamecoding.co.uk)

Yes, its possible - I didnt think it would be, but Dx8 CAN and DOES compile resonably cleanly on the Free C++ compiler DEV-C++

You will need everything contained in this file as well as a working DEV-C compiler.

PLEASE NOTE ALL THESE FILES ARE TAKEN FROM VARIOUS SOURCES AND ONLY GROUPED TOGETHER BY ME FOR EASE OF USE. I AM NOT RESPONSIBLE FOR ANY OF THE HARD WORK INVOLVED IN CONVERTING THE ENCLOSED FILES OVER TO MINGW (DEV) FORMAT. A FULL LIST OF CONTRIBUTORS CAN BE FOUND ON MY SITE.

INSTALLING THE FILES
--------------------

Assuming that you installed DEV to the default directory.. HERE GOES !!

First your working directory (for your programs) - I called mine 'MYSTUFF', which has the path C:\Dev-C++\mystuff

Copy the DLL file from the zip to this directory, it is important that this file accompanies any programs you have written in the same dir as your EXE.
(or you could just shove it in your WINDOWS\SYSTEM directory)

Copy all the LIB files from the ZIPPED LIB directory into your Dev-C++ LIB dir (C:\Dev-C++\lib)

Make a directory called 'DX8' inside your Dev INCLUDE dir and copy all the INCLUDE files over to it. (C:\Dev-C++\include\dx8)

THE PROJECTS
------------

So now everythings in place all that is left to configure is your project..

Always remember to compile for a WIN32 APPLICATION !! (a common mistake)

Make up the project file as normal, deleting the template code that is created if you so wish. You could if you wanted copy the contents of the TEST.CPP file in the EXAMPLE folder to test things are working.

Goto the PROJECT menu and select PROJECT OPTIONS...

in the FURTHER OBJECT FILES OR LINKER box enter:

C:\Dev-C++\Lib\libd3d8.a C:\Dev-C++\Lib\libd3dx8d.a C:\Dev-C++\Lib\libgdi32.a  C:\Dev-C++\Lib\libdxguid.a

This will add the necessary files to link in the 3D side of directx, if you wanted to use DDRAW, DINPUT or other DX moduiles then the other Library files will need to added.

(C:\Dev-C++\Lib\libddraw.a - DDRAW
 C:\Dev-C++\Lib\libdinput.a C:\Dev-C++\Lib\libdinput8.a - DINPUT etc...)

goto the menu OPTIONS, COMPILER OPTIONS
in the box 'ADD THE FOLLOWING COMMANDS WHEN CALLING COMPILER', enter:

-fvtable-thunks

in the 'ADD THE DIRECTORY BELOW TO BE SEARCHED FOR INCLUDE FILES' box enter:

C:\DEV-C++\Include\dx8\

This will inform the compiler to search for the directx headers in the correct directory.

And that's it.. Hopefully things will now compile cleanly.
I will be converting the existing Directx tuts on my site over to Dev although its not too hard to work it out for yourself. (hint: link the DDRAW lib)

Paul Gerfen
paul@gamecoding.co.uk
www.gamecoding.co.uk




